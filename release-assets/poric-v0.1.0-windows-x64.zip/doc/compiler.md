# Native compiler

`poric` is a C++17 ahead-of-time compiler for PORI. It parses and checks PORI,
expands static includes, generates one C++ translation unit, then invokes MSVC
through CMake to compile and link a native Windows executable. There is no PORI
interpreter, embedded source evaluator, or runtime DLL. The C++ runtime is linked
statically. Both `poric` and its output can be built as x86 or x64 executables.

This first backend targets Windows. Linux ELF output and a direct assembly or
LLVM backend are not implemented.

## Requirements

For building `poric` or compiling PORI programs:

- Windows with CMake 3.21 or newer on `PATH`.
- Visual Studio 2022 or its Build Tools, including **Desktop development with
  C++**, the x86/x64 MSVC tools, and a Windows SDK.
- Python 3, optionally, to run the tests. Python is not needed to use `poric`.

A compiled PORI program needs only Windows of the appropriate architecture.
x86 output also runs on x64 Windows. x64 output requires x64 Windows.

## Build the compiler

From PowerShell in the repository root:

```powershell
cmake --preset x64
cmake --build --preset x64
cmake --preset x86
cmake --build --preset x86
```

The resulting compilers are `build/x64/Release/poric.exe` and
`build/x86/Release/poric.exe`. Either compiler can generate either target.

For another Visual Studio version, use its installed CMake generator explicitly:

```powershell
cmake -S . -B build/custom -G "Visual Studio 18 2026" -A x64
cmake --build build/custom --config Release
```

The compiler uses the Visual Studio generator with which it was built. Override
it at compile time with `--generator "Visual Studio 17 2022"` if necessary.
The native backend currently requires a Visual Studio generator; Ninja and
MinGW are not supported by that backend.

See the [CMake Visual Studio generator documentation](https://cmake.org/cmake/help/latest/generator/Visual%20Studio%2017%202022.html)
for `Win32` and `x64` platform selection and the
[Microsoft build tools documentation](https://learn.microsoft.com/en-us/cpp/build/building-on-the-command-line)
for installing the C++ toolchain.

## Compile and run PORI

```powershell
New-Item -ItemType Directory -Force out | Out-Null
.\build\x64\Release\poric.exe examples/hello.pori --target x64 -o out/hello-x64.exe
.\build\x64\Release\poric.exe examples/hello.pori --target x86 -o out/hello-x86.exe
.\out\hello-x64.exe
.\out\hello-x86.exe
```

Both programs print:

```text
tuu porriin pistetään sut pärekorriin
ÄSSÄT
Ässät
```

Without `--target`, output defaults to x64. Without `-o`, the executable is
written beside the source with an `.exe` extension. Output directories must
already exist. Existing output is replaced after a successful native build.
The compiler rejects output paths that would overwrite its source files.

Check syntax without invoking MSVC or writing files:

```powershell
.\build\x64\Release\poric.exe --check examples/math.pori
```

Inspect the generated translation unit without invoking the native backend:

```powershell
.\build\x64\Release\poric.exe --emit-cpp examples/math.pori -o out/math.cpp
```

The generated file is self-contained. `--emit-cpp` does not select a binary
architecture; the later C++ compilation determines that. Use `--help` for all
options.

## Implemented language rules

The original [language sketch](base_structure.md) remains the starting point.
These rules settle its ambiguities for compiler version 0.1:

- Source is valid UTF-8, with an optional BOM. LF and CRLF work. Commands and
  variable names are case insensitive, including `Ä`, `Ö`, and `Å`.
- Each nonblank, noncomment line contains one statement ending in a period.
  Decimal points and periods inside strings do not terminate the statement.
- Every file, including an included file, starts with `eläks_viel.` and ends
  with `koit_pärjäil.`. Code outside those tags is an error.
- `#` starts a comment outside a quoted string. Strings support `\"`, `\\`,
  `\n`, `\r`, and `\t`. Multiline strings are not supported.
- Identifiers contain ASCII letters, digits, underscores, and Finnish/Swedish
  `äöåÄÖÅ`; they cannot start with a digit. They must be declared before use.
  Duplicate declarations, even with different case, are errors.
- `tos_o nimi.` creates an empty string. The optional initializer in
  `tos_o luku 42.` or `tos_o nimi "Pori".` is a small addition to the sketch.
  An initializer can also copy an earlier variable.
- `kuulustel` and `kuulostel` read a whole line into an existing variable.
  Input remains text until a numeric operation converts it. EOF is an error.
- `sössötä` prints one line. Within its quoted operand, `%nimi%` interpolates
  an existing variable and `%%` prints a literal percent. Interpolation also
  works in `mäikätä`; stored strings and initializers are not recursively
  interpolated.
- `mäikätä` uppercases ASCII and Finnish/Swedish `äöå`. Other Unicode text is
  preserved; full Unicode case conversion is not implemented.
- `nulju` / `pihi` subtract an amount from a variable. Amounts may be numeric
  literals or earlier variables. Numeric operations use finite IEEE-754
  double values, with a decimal point and optional exponent. Numeric strings
  from input are accepted; malformed values and overflow fail. Results print
  with up to 15 significant digits, so this is not exact decimal arithmetic.
- `funderaat` / `funteerat` accept numeric seconds or an earlier variable.
  Fractional seconds work. Negative values, nonnumbers, and values above
  2147483647 seconds fail.
- `kampraati` / `kamraari` include a literal file path, quoted if it contains
  spaces. The path is relative to the file containing the command. Includes
  are expanded at compile time, share variables, and need no source files at
  runtime. Cycles and nesting beyond 128 active files are errors. An included
  closing tag returns to the caller without printing a success marker.
- `ei mittää.` ends the whole program successfully, including from an included
  file. `rauma.` ends it with an error. Ending the outer program normally or
  using `ei mittää` prints exactly one `Ässät` line and returns exit code 0.
- Syntax errors stop compilation. Runtime failures report
  `Pölvästi path:line: reason` on stderr, return exit code 1, and print no
  success marker. The compiler checks all source, including unreachable lines.

Version 0.1 has no general assignment, expressions, conditionals, loops,
functions, or dynamic file loading. Those constructs were not specified in the
original language sketch.

## Tests

```powershell
ctest --preset x64
ctest --preset x86
```

The frontend suite checks the examples, syntax failures, UTF-8, case handling,
includes, generated source escaping, CLI validation, and output preservation.
The native suite compiles and runs programs for both targets, checks the PE
machine headers, and verifies I/O, arithmetic, aliases, interpolation, Finnish
uppercase, pauses, termination, and runtime failures. It exercises paths with
spaces, Unicode and shell metacharacters. Native tests require both MSVC target
toolchains and an x64 Windows host to execute both architectures.

GitHub Actions builds both compiler architectures, runs these suites, and
uploads the compiler executables as artifacts.

Version tags also trigger
[release packaging](https://github.com/JanneHonkonen/pori/blob/main/doc/releases.md),
with tested x86/x64 ZIP downloads and checksums attached to a draft GitHub Release.
