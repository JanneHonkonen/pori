# PORI native compiler v0.1.0 for Windows x64

Author: **Janne Honkonen**

This package contains the native x64 compiler as `poric.exe`, examples, and
language documentation. Either compiler architecture can produce x86 or x64
programs. The x64 compiler needs x64 Windows; the x86 compiler runs on either.

## Requirements

To compile programs, install CMake 3.21 or newer on PATH and Visual Studio 2022
or its Build Tools with Desktop development with C++, the MSVC x86/x64 tools,
and a Windows SDK. The compiler uses MSVC to generate native machine code.
Compiled programs run without a PORI interpreter or a separate C++ runtime DLL.

## Try it

Extract the ZIP, open PowerShell in the extracted directory, and run:

```powershell
.\poric.exe --version
.\poric.exe --check examples/hello.pori
.\poric.exe examples/hello.pori --target x64 -o hello-x64.exe
.\poric.exe examples/hello.pori --target x86 -o hello-x86.exe
.\hello-x86.exe
```

On x64 Windows you can also run `.\hello-x64.exe`. Output defaults to x64;
use `--target x86` explicitly for 32-bit output. `--check` and `--emit-cpp` work
without CMake or MSVC. Use `--help` for all options.

See [language rules and compiler documentation](doc/compiler.md) and
[the original language sketch](doc/base_structure.md).

Source and releases: [JanneHonkonen/pori](https://github.com/JanneHonkonen/pori).

The release's `SHA256SUMS.txt` contains checksums for the ZIP downloads.
